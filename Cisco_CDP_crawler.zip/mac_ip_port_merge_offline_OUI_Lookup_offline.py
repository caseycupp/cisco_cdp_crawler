


________________________________________________________________
Below is a full updated script that outputs:

Format:
ip, mac, vlan, switch, sw_port, firewall, fw_intf, vendor

It still supports:
multiple switches in one Cisco file (prompt/divider/hostname)
multiple firewalls in one Palo file (prompt/divider)
optional offline vendor lookup via --oui









#!/usr/bin/env python3
"""
mac_ip_port_merge.py
====================

Output format (CSV columns)
---------------------------
ip, mac, vlan, switch, sw_port, firewall, fw_intf, vendor

Behavior
--------
- Joins Palo Alto ARP + Cisco MAC table using MAC address as the key (correct join key).
- Sorts final output by IP address ONLY (numerically). Blank/malformed IPs go to the bottom.
- Supports multiple switches in one Cisco file (prompt/divider/hostname).
- Supports multiple firewalls in one Palo Alto file (prompt/divider).
- Optional offline vendor lookup via OUI database file (--oui).

Inputs
------
1) Palo Alto ARP output file (from: `show arp all`)
2) Cisco MAC address-table output file (can include multiple switches)
3) Optional offline OUI vendor DB (OUI->Vendor)

================================================================================
HOW TO USE
================================================================================

A) Palo Alto ARP file
---------------------
On Palo Alto:
  > show arp all

Save output to:
  palo_arp.txt

If combining MULTIPLE firewalls into one file, include boundaries:

METHOD 1 (best): prompt lines
Example:
  PA-FW1> show arp all
  ...arp lines...
  PA-FW2> show arp all
  ...arp lines...

METHOD 2: divider lines
Example:
  ===== FIREWALL: PA-FW1 =====
  ...arp lines...
  ===== FIREWALL: PA-FW2 =====
  ...arp lines...

B) Cisco MAC table file (multiple switches OK)
----------------------------------------------
On each Cisco switch:
  terminal length 0
  show mac address-table

Save combined output to:
  cisco_macs.txt

If combining MULTIPLE switches into one file, include boundaries:

METHOD 1 (best): prompt lines
Example:
  SW1# show mac address-table
   10    aaaa.bbbb.cccc   DYNAMIC   Gi1/0/24

  SW2# show mac address-table
   10    aaaa.bbbb.cccc   DYNAMIC   Te1/1/1

METHOD 2: divider lines
Example:
  ===== SWITCH: SW1 =====
   10    aaaa.bbbb.cccc   DYNAMIC   Gi1/0/24
  ===== SWITCH: SW2 =====
   10    aaaa.bbbb.cccc   DYNAMIC   Te1/1/1

METHOD 3: hostname lines
Example:
  hostname SW1
   10    aaaa.bbbb.cccc   DYNAMIC   Gi1/0/24
  hostname SW2
   10    aaaa.bbbb.cccc   DYNAMIC   Te1/1/1

C) Optional offline vendor lookup (OUI DB)
------------------------------------------
Recommended SIMPLE CSV:
  oui_db.csv:
    OUI,VENDOR
    aabbcc,Cisco Systems
    001a2b,Palo Alto Networks

Run without vendor:
  python mac_ip_port_merge.py --arp palo_arp.txt --mac cisco_macs.txt --out merged.csv

Run with vendor:
  python mac_ip_port_merge.py --arp palo_arp.txt --mac cisco_macs.txt --out merged.csv --oui oui_db.csv

Only rows where MAC exists in ARP (has IP):
  python mac_ip_port_merge.py --arp palo_arp.txt --mac cisco_macs.txt --out merged.csv --only-matched

================================================================================
"""

from __future__ import annotations

import argparse
import csv
import ipaddress
import re
from pathlib import Path
from typing import Dict, List, Tuple, Optional, Iterable


# ------------------------------------------------------------------------------
# MAC normalization
# ------------------------------------------------------------------------------

def normalize_mac(mac: str) -> Optional[str]:
    """Normalize MAC into lowercase colon-separated: aa:bb:cc:dd:ee:ff"""
    if not mac:
        return None
    s = mac.strip().lower()
    s = s.replace(".", "").replace(":", "").replace("-", "")
    if len(s) != 12 or not re.fullmatch(r"[0-9a-f]{12}", s):
        return None
    return ":".join(s[i:i+2] for i in range(0, 12, 2))


def mac_to_oui6(mac_norm: str) -> str:
    """Return OUI as 6 hex chars: aabbcc"""
    return mac_norm.replace(":", "")[:6].lower()


# ------------------------------------------------------------------------------
# Offline OUI vendor database
# ------------------------------------------------------------------------------

OUI_RE = re.compile(r"^\s*([0-9A-Fa-f]{2}([:\-\.]?[0-9A-Fa-f]{2}){2}|[0-9A-Fa-f]{6})\b")

def normalize_oui(oui: str) -> Optional[str]:
    if not oui:
        return None
    s = oui.strip().lower().replace(":", "").replace("-", "").replace(".", "")
    if len(s) != 6 or not re.fullmatch(r"[0-9a-f]{6}", s):
        return None
    return s

def load_oui_db(path: Optional[str]) -> Dict[str, str]:
    """
    Loads offline OUI->Vendor map.
    Best: simple CSV with header OUI,VENDOR
    Also supports loose text lines: "AA:BB:CC  Vendor Name"
    """
    if not path:
        return {}

    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"OUI database file not found: {path}")

    oui_map: Dict[str, str] = {}

    # Try CSV first
    try:
        with p.open("r", encoding="utf-8", errors="replace", newline="") as f:
            reader = csv.reader(f)
            rows = list(reader)

        start_idx = 0
        if rows and rows[0] and rows[0][0].strip().lower() in ("oui", "assignment", "registry"):
            start_idx = 1

        for r in rows[start_idx:]:
            if not r:
                continue
            oui_raw = r[0].strip() if len(r) >= 1 else ""
            vendor_raw = r[1].strip() if len(r) >= 2 else (r[-1].strip() if r else "")
            oui6 = normalize_oui(oui_raw)
            if oui6 and vendor_raw:
                oui_map[oui6] = vendor_raw

        if len(oui_map) >= 10:
            return oui_map
        oui_map.clear()
    except Exception:
        pass

    # Loose text fallback
    text = p.read_text(encoding="utf-8", errors="replace")
    for ln in text.splitlines():
        if not ln.strip():
            continue
        m = OUI_RE.match(ln)
        if not m:
            continue
        oui6 = normalize_oui(m.group(1))
        if not oui6:
            continue
        vendor = ln[m.end():].strip(" \t,-;")
        vendor = re.sub(r"\s{2,}", " ", vendor).strip()
        if vendor:
            oui_map[oui6] = vendor

    return oui_map


# ------------------------------------------------------------------------------
# Palo Alto: show arp all parsing (firewall name + interface)
# ------------------------------------------------------------------------------

IP_RE = re.compile(
    r"\b(?:(?:25[0-5]|2[0-4]\d|1?\d?\d)\.){3}(?:25[0-5]|2[0-4]\d|1?\d?\d)\b"
)
MAC_ANY_RE = re.compile(
    r"\b(?:"
    r"[0-9A-Fa-f]{4}\.[0-9A-Fa-f]{4}\.[0-9A-Fa-f]{4}"
    r"|[0-9A-Fa-f]{2}(?::[0-9A-Fa-f]{2}){5}"
    r"|[0-9A-Fa-f]{2}(?:-[0-9A-Fa-f]{2}){5}"
    r")\b"
)

FW_PROMPT_RE = re.compile(r"^\s*([A-Za-z0-9._-]+)\s*[>#]\s*$")  # e.g. PA-FW1> or PA-FW1#
FW_DIVIDER_RE = re.compile(r"^\s*=+\s*FIREWALL:\s*([A-Za-z0-9._-]+)\s*=+\s*$", re.IGNORECASE)

# Interface tokens like ethernet1/3, ethernet1/3.20, ae1.20, vlan.10
FW_INTF_RE = re.compile(
    r"\b(?:ethernet\d+/\d+(?:/\d+)?(?:\.\d+)?|ae\d+(?:\.\d+)?|vlan\.\d+)\b",
    re.IGNORECASE
)

def parse_palo_arp(text: str) -> Dict[str, Tuple[str, str, str]]:
    """
    Returns: mac_norm -> (ip, firewall_name, fw_intf)
    If a MAC appears multiple times, last one wins.
    """
    mac_to_info: Dict[str, Tuple[str, str, str]] = {}
    current_fw = "UNKNOWN_FIREWALL"

    for line in text.splitlines():
        m_div = FW_DIVIDER_RE.match(line)
        if m_div:
            current_fw = m_div.group(1)
            continue

        m_prompt = FW_PROMPT_RE.match(line)
        if m_prompt:
            current_fw = m_prompt.group(1)
            continue

        ip_m = IP_RE.search(line)
        mac_m = MAC_ANY_RE.search(line)
        if not ip_m or not mac_m:
            continue

        ip = ip_m.group(0)
        mac_norm = normalize_mac(mac_m.group(0))
        if not mac_norm:
            continue

        intf_m = FW_INTF_RE.search(line)
        fw_intf = intf_m.group(0) if intf_m else ""

        mac_to_info[mac_norm] = (ip, current_fw, fw_intf)

    return mac_to_info


# ------------------------------------------------------------------------------
# Cisco: show mac address-table parsing (VLAN + switch + port)
# ------------------------------------------------------------------------------

CISCO_MAC_LINE_RE = re.compile(
    r"^\s*(?P<vlan>\d+)\s+"
    r"(?P<mac>(?:[0-9A-Fa-f]{4}\.[0-9A-Fa-f]{4}\.[0-9A-Fa-f]{4}|"
    r"[0-9A-Fa-f]{2}(?::[0-9A-Fa-f]{2}){5}|"
    r"[0-9A-Fa-f]{2}(?:-[0-9A-Fa-f]{2}){5})\s+)"
    r"(?P<type>\S+)\s+"
    r"(?P<port>\S+)\s*$"
)

PROMPT_SWITCH_RE = re.compile(r"^\s*([A-Za-z0-9._-]+)\s*#\s*$")
HOSTNAME_RE = re.compile(r"^\s*hostname\s+([A-Za-z0-9._-]+)\s*$", re.IGNORECASE)
SWITCH_DIVIDER_RE = re.compile(r"^\s*=+\s*SWITCH:\s*([A-Za-z0-9._-]+)\s*=+\s*$", re.IGNORECASE)

def parse_cisco_mac(text: str) -> List[Tuple[str, str, str, str]]:
    """
    Returns list of: (mac_norm, vlan, switch, sw_port)
    """
    results: List[Tuple[str, str, str, str]] = []
    current_switch = "UNKNOWN_SWITCH"

    for line in text.splitlines():
        m_div = SWITCH_DIVIDER_RE.match(line)
        if m_div:
            current_switch = m_div.group(1)
            continue

        m_prompt = PROMPT_SWITCH_RE.match(line)
        if m_prompt:
            current_switch = m_prompt.group(1)
            continue

        m_host = HOSTNAME_RE.match(line)
        if m_host:
            current_switch = m_host.group(1)
            continue

        m = CISCO_MAC_LINE_RE.match(line)
        if not m:
            continue

        vlan = m.group("vlan").strip()
        mac_norm = normalize_mac(m.group("mac"))
        sw_port = m.group("port").strip()

        if mac_norm:
            results.append((mac_norm, vlan, current_switch, sw_port))

    return results


# ------------------------------------------------------------------------------
# Sorting: IP only (blank/malformed IPs go last)
# ------------------------------------------------------------------------------

def ip_sort_key(row: dict):
    ip = row.get("ip", "")
    if not ip:
        return (1, ipaddress.IPv4Address("0.0.0.0"))
    try:
        return (0, ipaddress.IPv4Address(ip))
    except ValueError:
        return (1, ipaddress.IPv4Address("0.0.0.0"))


# ------------------------------------------------------------------------------
# Merge + output (ORDER: ip, mac, vlan, switch, sw_port, firewall, fw_intf, vendor)
# ------------------------------------------------------------------------------

def vendor_for_mac(mac_norm: str, oui_db: Dict[str, str]) -> str:
    if not oui_db:
        return "UNKNOWN"
    return oui_db.get(mac_to_oui6(mac_norm), "UNKNOWN")

def merge(
    arp_map: Dict[str, Tuple[str, str, str]],
    cisco_entries: Iterable[Tuple[str, str, str, str]],
    oui_db: Dict[str, str]
) -> List[Dict[str, str]]:
    rows: List[Dict[str, str]] = []

    for mac_norm, vlan, switch, sw_port in cisco_entries:
        ip, firewall, fw_intf = arp_map.get(mac_norm, ("", "", ""))
        vendor = vendor_for_mac(mac_norm, oui_db)

        rows.append({
            "ip": ip,
            "mac": mac_norm,
            "vlan": vlan,
            "switch": switch,
            "sw_port": sw_port,
            "firewall": firewall,
            "fw_intf": fw_intf,
            "vendor": vendor,
        })

    return rows

def write_csv(rows: List[Dict[str, str]], out_path: Path) -> None:
    out_path.parent.mkdir(parents=True, exist_ok=True)

    fieldnames = ["ip", "mac", "vlan", "switch", "sw_port", "firewall", "fw_intf", "vendor"]

    with out_path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        for r in rows:
            w.writerow(r)

def main() -> int:
    ap = argparse.ArgumentParser(
        description="Merge Palo Alto ARP + Cisco MAC address-table into CSV (sorted by IP)."
    )
    ap.add_argument("--arp", required=True, help="Text file from Palo Alto: `show arp all`")
    ap.add_argument("--mac", required=True, help="Text file from Cisco: `show mac address-table` (multiple switches allowed)")
    ap.add_argument("--out", required=True, help="Output CSV path")
    ap.add_argument("--oui", required=False, default=None, help="Optional offline OUI database file (simple CSV recommended)")
    ap.add_argument("--only-matched", action="store_true",
                    help="Only output rows where MAC exists in ARP (has IP).")

    args = ap.parse_args()

    arp_text = Path(args.arp).read_text(encoding="utf-8", errors="replace")
    mac_text = Path(args.mac).read_text(encoding="utf-8", errors="replace")

    arp_map = parse_palo_arp(arp_text)
    cisco_entries = parse_cisco_mac(mac_text)
    oui_db = load_oui_db(args.oui)

    rows = merge(arp_map, cisco_entries, oui_db)

    if args.only_matched:
        rows = [r for r in rows if r["ip"]]

    # Sort output by IP only (numeric)
    rows.sort(key=ip_sort_key)

    write_csv(rows, Path(args.out))

    print(f"Wrote {len(rows)} rows to {args.out}")
    print(f"ARP MACs parsed: {len(arp_map)}")
    print(f"Cisco MAC entries parsed: {len(cisco_entries)}")
    print(f"OUI entries loaded: {len(oui_db)}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())








README

Run examples (Windows 11 / PowerShell)

python mac_ip_port_merge.py --arp palo_arp.txt --mac cisco_macs.txt --out merged.csv


No vendor lookup:
python mac_ip_port_merge.py --arp palo_arp.txt --mac cisco_macs.txt --out merged.csv


With vendor lookup:
python mac_ip_port_merge.py --arp palo_arp.txt --mac cisco_macs.txt --out merged.csv --oui oui_db.csv


Only entries that have an IP (present in ARP):
python mac_ip_port_merge.py --arp palo_arp.txt --mac cisco_macs.txt --out merged.csv --only-matched

If you find that fw_intf is coming out blank, paste 2–3 real ARP lines (sanitized is fine) and I’ll tune the interface regex to your exact Palo output format.




include prompts in the capture
Example combined file content:
-------------------------------------------------------------------
SW1# show mac address-table
          Mac Address Table
-------------------------------------------
Vlan    Mac Address       Type        Ports
----    -----------       --------    -----
  10    aaaa.bbbb.cccc    DYNAMIC     Gi1/0/24
  10    1111.2222.3333    DYNAMIC     Gi1/0/10

SW2# show mac address-table
          Mac Address Table
-------------------------------------------
Vlan    Mac Address       Type        Ports
----    -----------       --------    -----
  10    aaaa.bbbb.cccc    DYNAMIC     Te1/1/1
  20    bbbb.cccc.dddd    DYNAMIC     Gi0/5
----------------------------------------------





==========================================================


To add the offline OUI/vendor lookup, you just need one extra file (an OUI database) and add --oui <file> when you run the script.


1) Create an OUI database file (simplest way)
Make a file named oui_db.csv in the same folder as your script.
Format:

OUI,VENDOR
aabbcc,Cisco Systems
001a2b,Palo Alto Networks
f0de71,Apple, Inc.


Rules:
OUI = first 6 hex characters of a MAC (no separators required)
VENDOR = the vendor name
Lower/upper case doesn’t matter
If the vendor has commas, put it in quotes:

f0de71,"Apple, Inc."
You can start small and keep adding OUIs as you see them.


2) Run the script with the OUI file

python mac_ip_port_merge.py --arp palo_arp.txt --mac cisco_macs.txt --out merged.csv --oui oui_db.csv

Now the vendor column will be populated when the OUI is found.


3) Where do you get OUIs to put in the file?
Fast manual way (works right now)

1. Look at a MAC from your output, e.g. aa:bb:cc:dd:ee:ff
2. OUI is the first 3 bytes: aa:bb:cc → write it as aabbcc
3. Add it to oui_db.csv

Better way (bulk)
If you already have a big OUI list (IEEE or other), you can use it too — the script will try to parse common formats. But the simple CSV above is the most reliable.

4) Confirm it loaded

When you run, the script prints:
  OUI entries loaded: <number>
If it says 0, either:
  the file path is wrong, or
  the format didn’t parse (simple CSV fixes that)

5) Example folder layout
C:\tools\macmerge\
  mac_ip_port_merge.py
  palo_arp.txt
  cisco_macs.txt
  oui_db.csv

If you want, paste 5–10 lines of the OUI file you plan to use (or tell me if you want the IEEE official list), and I’ll tell you the exact best format for it so it loads cleanly every time.






















